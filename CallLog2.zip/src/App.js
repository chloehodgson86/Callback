import React, { useEffect, useMemo, useState } from "react";

/* ---------- Config ---------- */
const STATUSES = ["Pending", "Done", "Escalated", "No-Answer"];
const STORAGE_KEY = "callback-tracker-editorial-v3";
const DEFAULT_AGENTS = [
  "Debbie",
  "Ekta",
  "Veronica",
  "Pearl",
  "Jade",
  "Evelyn",
  "Myra",
  "Char",
  "Angel",
  "Reynaldo",
  "Merry",
  "Elena",
  "Mildred",
  "Toa",
];

/* ---------- Utils ---------- */
const isoNow = () => new Date().toISOString();
const fmtDate = (iso) => (iso ? new Date(iso).toLocaleString() : "—");
const hoursBetween = (aIso, bIso) => (new Date(bIso) - new Date(aIso)) / 36e5;
const csvEscape = (v) =>
  /[",\n]/.test(String(v)) ? `"${String(v).replace(/"/g, '""')}"` : String(v);

export default function App() {
  /* ---------- State ---------- */
  const [items, setItems] = useState([]);
  const [agents, setAgents] = useState(DEFAULT_AGENTS);

  const [agentFilter, setAgentFilter] = useState("All");
  const [statusFilter, setStatusFilter] = useState("All");
  const [overdueOnly, setOverdueOnly] = useState(false);
  const [search, setSearch] = useState("");

  const [form, setForm] = useState({
    customer: "",
    phone: "",
    contactReason: "",
    agent: DEFAULT_AGENTS[0],
    dueAt: new Date(Date.now() + 36e5 * 24).toISOString(),
    status: "Pending",
    notes: "",
  });

  /* ---------- Load / Save ---------- */
  useEffect(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) {
        const parsed = JSON.parse(raw);
        setItems(parsed.items || []);
        setAgents(parsed.agents || DEFAULT_AGENTS);
      }
    } catch {}
  }, []);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify({ items, agents }));
    } catch {}
  }, [items, agents]);

  /* ---------- Derived ---------- */
  const nowIso = isoNow();
  const withDerived = useMemo(
    () =>
      items.map((i) => ({
        ...i,
        overdue: i.status !== "Done" && new Date(i.dueAt) < new Date(),
        ageHrs: Math.max(0, hoursBetween(i.createdAt, nowIso)),
      })),
    [items, nowIso]
  );

  const filtered = useMemo(
    () =>
      withDerived.filter(
        (i) =>
          (agentFilter === "All" || i.agent === agentFilter) &&
          (statusFilter === "All" || i.status === statusFilter) &&
          (!overdueOnly || i.overdue) &&
          (!search ||
            i.customer.toLowerCase().includes(search.toLowerCase()) ||
            (i.notes || "").toLowerCase().includes(search.toLowerCase()) ||
            (i.contactReason || "")
              .toLowerCase()
              .includes(search.toLowerCase()))
      ),
    [withDerived, agentFilter, statusFilter, overdueOnly, search]
  );

  /* ---------- Actions ---------- */
  function addItem() {
    if (!form.customer.trim()) return alert("Customer required");
    const now = isoNow();
    setItems((prev) => [
      {
        id: Math.random().toString(36).slice(2),
        createdAt: now,
        completedAt: "",
        ...form,
      },
      ...prev,
    ]);
    setForm((f) => ({
      ...f,
      customer: "",
      phone: "",
      contactReason: "",
      notes: "",
      dueAt: new Date(Date.now() + 36e5 * 24).toISOString(),
      status: "Pending",
    }));
  }

  const updateItem = (id, patch) =>
    setItems((p) => p.map((i) => (i.id === id ? { ...i, ...patch } : i)));
  const markDone = (id) =>
    updateItem(id, { status: "Done", completedAt: isoNow() });
  const escalate = (id) => updateItem(id, { status: "Escalated" });
  const removeItem = (id) => setItems((p) => p.filter((i) => i.id !== id));

  /* ---------- Export ---------- */
  function exportCSV() {
    const headers = [
      "id",
      "date",
      "customer",
      "phone",
      "contactReason",
      "agent",
      "dueAt",
      "status",
      "notes",
      "createdAt",
      "completedAt",
    ];
    const rows = items.map((i) =>
      headers.map((h) => csvEscape(i[h] ?? "")).join(",")
    );
    const csv = [headers.join(","), ...rows].join("\n");
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "callback-tracker.csv";
    a.click();
    URL.revokeObjectURL(url);
  }

  /* ---------- UI ---------- */
  return (
    <PageShell exportCSV={exportCSV}>
      {/* Hero */}
      <section className="mb-10 md:mb-14">
        <div className="max-w-3xl">
          <h2 className="font-serif text-4xl md:text-5xl leading-tight tracking-tight">
            Paramount Liquor
            <br className="hidden sm:block" /> Callbacks
          </h2>
          <p className="mt-3 md:mt-4 text-neutral-600">
            To be actioned daily, prior to cut off
          </p>
        </div>
      </section>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 md:gap-10">
        {/* Left side (form + table) */}
        <div className="lg:col-span-2 space-y-8 md:space-y-10">
          <SectionCard title="Log a Callback">
            <div className="grid md:grid-cols-2 gap-5">
              <Field label="Customer">
                <Input
                  value={form.customer}
                  onChange={(v) => setForm({ ...form, customer: v })}
                  placeholder="Catchment Brewing"
                />
              </Field>
              <Field label="Phone">
                <Input
                  value={form.phone}
                  onChange={(v) => setForm({ ...form, phone: v })}
                  placeholder="03 9000 0000"
                />
              </Field>
              <Field label="Reason">
                <Input
                  value={form.contactReason}
                  onChange={(v) => setForm({ ...form, contactReason: v })}
                  placeholder="Overdue invoice"
                />
              </Field>
              <Field label="Agent">
                <Select
                  value={form.agent}
                  onChange={(v) => setForm({ ...form, agent: v })}
                  options={agents}
                />
              </Field>
              <Field label="Due by">
                <input
                  type="datetime-local"
                  className="w-full px-4 py-3 rounded-[14px] border border-neutral-200 bg-[#f9f9f8] hover:bg-neutral-50 focus:outline-none focus:ring-2 focus:ring-[#c7bca4] transition-all"
                  value={new Date(form.dueAt).toISOString().slice(0, 16)}
                  onChange={(e) =>
                    setForm({
                      ...form,
                      dueAt: new Date(e.target.value).toISOString(),
                    })
                  }
                />
              </Field>
              <Field label="Status">
                <Select
                  value={form.status}
                  onChange={(v) => setForm({ ...form, status: v })}
                  options={STATUSES}
                />
              </Field>
              <Field label="Notes" stretch>
                <textarea
                  rows={3}
                  className="w-full px-4 py-3 rounded-[16px] border border-neutral-200 bg-[#f9f9f8] hover:bg-neutral-50 focus:outline-none focus:ring-2 focus:ring-[#c7bca4] transition-all"
                  placeholder="Left VM; will pay Friday."
                  value={form.notes}
                  onChange={(e) => setForm({ ...form, notes: e.target.value })}
                />
              </Field>
            </div>

            <div className="mt-8 flex justify-end">
              <PrimaryButton onClick={addItem}>Add callback</PrimaryButton>
            </div>
          </SectionCard>

          <SectionCard
            title="Callbacks"
            subtitle="Your active and completed items"
          >
            <div className="overflow-auto rounded-[16px] border border-neutral-100">
              <table className="min-w-full text-sm">
                <thead className="sticky top-0 bg-white/90 backdrop-blur">
                  <tr>
                    <Th>Customer</Th>
                    <Th>Agent</Th>
                    <Th>Reason</Th>
                    <Th>Created</Th>
                    <Th>Due</Th>
                    <Th>Status</Th>
                    <Th>Notes</Th>
                    <Th>Actions</Th>
                  </tr>
                </thead>
                <tbody className="[&_tr:nth-child(even)]:bg-neutral-50/40">
                  {filtered.map((i) => (
                    <tr
                      key={i.id}
                      className={`border-t transition-colors hover:bg-neutral-50 ${
                        i.overdue && i.status !== "Done" ? "bg-rose-50/40" : ""
                      }`}
                    >
                      <Td>
                        <div className="font-medium">{i.customer}</div>
                        {i.phone && (
                          <a
                            href={`tel:${i.phone}`}
                            className="text-xs text-neutral-500 underline"
                          >
                            {i.phone}
                          </a>
                        )}
                      </Td>
                      <Td>{i.agent}</Td>
                      <Td>{i.contactReason || "—"}</Td>
                      <Td>{fmtDate(i.createdAt)}</Td>
                      <Td>{fmtDate(i.dueAt)}</Td>
                      <Td>
                        <StatusPill status={i.status} overdue={i.overdue} />
                      </Td>
                      <Td>
                        <InlineEdit
                          value={i.notes || ""}
                          onChange={(v) => updateItem(i.id, { notes: v })}
                          placeholder="Add a quick note…"
                        />
                      </Td>
                      <Td>
                        <div className="flex flex-wrap gap-2">
                          {i.status !== "Done" && (
                            <SoftButton onClick={() => markDone(i.id)}>
                              Done
                            </SoftButton>
                          )}
                          <SoftButton onClick={() => escalate(i.id)}>
                            Escalate
                          </SoftButton>
                          <SoftButton
                            destructive
                            onClick={() => removeItem(i.id)}
                          >
                            Delete
                          </SoftButton>
                        </div>
                      </Td>
                    </tr>
                  ))}
                  {!filtered.length && (
                    <tr>
                      <td colSpan={8}>
                        <div className="flex flex-col items-center justify-center py-16 text-center">
                          <div className="text-4xl mb-3">🕊️</div>
                          <p className="text-neutral-600">
                            No records match your filters.
                          </p>
                          <p className="text-neutral-400 text-xs mt-1">
                            Try clearing filters or logging a new callback.
                          </p>
                        </div>
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </SectionCard>
        </div>

        {/* Right side (filters) */}
        <div className="space-y-8 md:space-y-10">
          <SectionCard title="Filters">
            <div className="space-y-4">
              <div className="space-y-2">
                <Label>Agent</Label>
                <TagPicker
                  value={agentFilter}
                  onChange={setAgentFilter}
                  options={["All", ...agents]}
                />
              </div>
              <div className="space-y-2">
                <Label>Status</Label>
                <TagPicker
                  value={statusFilter}
                  onChange={setStatusFilter}
                  options={["All", ...STATUSES]}
                />
              </div>
              <label className="flex items-center gap-3 text-sm text-neutral-700">
                <input
                  type="checkbox"
                  checked={overdueOnly}
                  onChange={(e) => setOverdueOnly(e.target.checked)}
                />
                Overdue only
              </label>
              <Input
                value={search}
                onChange={setSearch}
                placeholder="Search customer / notes / reason"
              />
            </div>
          </SectionCard>
        </div>
      </div>
    </PageShell>
  );
}

/* ---------- Shell ---------- */
function PageShell({ children, exportCSV }) {
  return (
    <div className="min-h-screen bg-[#f7f5f2] text-[#222] font-sans">
      {/* subtle paper-like background */}
      <div
        className="pointer-events-none fixed inset-0 -z-10 opacity-[0.35]"
        style={{
          backgroundImage:
            "radial-gradient(40rem 40rem at 10% 10%, #ffffff 0, rgba(247,245,242,0) 70%), radial-gradient(30rem 30rem at 90% 20%, #ffffff 0, rgba(247,245,242,0) 60%)",
        }}
      />
      <SiteHeader exportCSV={exportCSV} />
      <main className="max-w-7xl mx-auto px-5 md:px-8 lg:px-10 py-10 md:py-12">
        {children}
      </main>
      <SiteFooter />
    </div>
  );
}

function SiteHeader({ exportCSV }) {
  return (
    <header className="border-b border-black/5 bg-[#f7f5f2]/80 backdrop-blur sticky top-0 z-10">
      <div className="max-w-7xl mx-auto px-5 md:px-8 lg:px-10 py-5 md:py-6 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <span className="h-9 w-9 rounded-2xl bg-black text-[#f7f5f2] grid place-items-center">
            ◎
          </span>
          <h1 className="font-serif text-2xl md:text-3xl tracking-tight">
            Callback Tracker
          </h1>
        </div>
        <div className="flex gap-2">
          <SoftButton onClick={exportCSV}>Export CSV</SoftButton>
          <SoftButton
            onClick={() => {
              if (confirm("Reset all data?")) {
                localStorage.removeItem(STORAGE_KEY);
                location.reload();
              }
            }}
          >
            Reset
          </SoftButton>
        </div>
      </div>
    </header>
  );
}

function SiteFooter() {
  return (
    <footer className="border-t border-black/5 mt-14">
      <div className="max-w-7xl mx-auto px-5 md:px-8 lg:px-10 py-8 text-xs text-neutral-500">
        Data is stored locally in your browser. Export CSV from the header.
      </div>
    </footer>
  );
}

/* ---------- Cards & table helpers ---------- */
function SectionCard({ title, subtitle, right, children }) {
  return (
    <section className="rounded-[24px] border border-black/5 bg-white shadow-[0_8px_20px_rgba(0,0,0,0.04)] p-6 md:p-8 transition-all">
      <div className="flex items-end justify-between mb-6">
        <div>
          {title && <h2 className="font-serif text-2xl">{title}</h2>}
          {subtitle && (
            <p className="text-sm text-neutral-500 mt-1">{subtitle}</p>
          )}
        </div>
        {right}
      </div>
      {children}
    </section>
  );
}

function Th({ children }) {
  return (
    <th className="py-3 px-4 text-left font-semibold text-neutral-500 border-b border-neutral-100">
      {children}
    </th>
  );
}
function Td({ children }) {
  return <td className="py-3 px-4 align-top">{children}</td>;
}

/* ---------- Inputs & buttons ---------- */
function PrimaryButton({ children, onClick }) {
  return (
    <button
      onClick={onClick}
      className="px-6 py-3 rounded-[18px] bg-[#222] text-[#f7f5f2] tracking-tight shadow-[0_6px_18px_rgba(0,0,0,0.15)] hover:shadow-[0_10px_24px_rgba(0,0,0,0.18)] active:translate-y-[1px] transition-all"
    >
      {children}
    </button>
  );
}

function SoftButton({ children, onClick, destructive }) {
  return (
    <button
      onClick={onClick}
      className={`px-4 py-2 rounded-[16px] border text-sm transition-all shadow-sm hover:shadow ${
        destructive
          ? "border-rose-200 text-rose-700 bg-rose-50 hover:bg-rose-100"
          : "border-neutral-200 text-neutral-900 bg-white hover:bg-neutral-50"
      }`}
    >
      {children}
    </button>
  );
}

function Field({ label, children, stretch }) {
  return (
    <div className={stretch ? "md:col-span-2 grid gap-2" : "grid gap-2"}>
      <Label>{label}</Label>
      {children}
    </div>
  );
}

function Label({ children }) {
  return (
    <div className="text-xs tracking-wide text-neutral-500">{children}</div>
  );
}

function Input({ value, onChange, placeholder }) {
  return (
    <input
      value={value}
      onChange={(e) => onChange(e.target.value)}
      placeholder={placeholder}
      className="w-full px-4 py-3 rounded-[14px] border border-neutral-200 bg-[#f9f9f8] hover:bg-neutral-50 focus:outline-none focus:ring-2 focus:ring-[#c7bca4] transition-all"
    />
  );
}

function Select({ value, onChange, options }) {
  return (
    <select
      value={value}
      onChange={(e) => onChange(e.target.value)}
      className="w-full px-4 py-3 rounded-[14px] border border-neutral-200 bg-[#f9f9f8] hover:bg-neutral-50 focus:outline-none focus:ring-2 focus:ring-[#c7bca4] transition-all"
    >
      {options.map((o) => (
        <option key={o}>{o}</option>
      ))}
    </select>
  );
}

function TagPicker({ value, onChange, options }) {
  return (
    <div className="flex flex-wrap gap-2">
      {options.map((o) => (
        <button
          key={o}
          onClick={() => onChange(o)}
          className={`px-4 py-2 rounded-[16px] border text-sm transition-all ${
            value === o
              ? "bg-[#222] text-[#f7f5f2] border-[#222]"
              : "bg-white border-neutral-200 text-neutral-800 hover:bg-neutral-50"
          }`}
        >
          {o}
        </button>
      ))}
    </div>
  );
}

function StatusPill({ status, overdue }) {
  const style =
    status === "Done"
      ? "bg-emerald-50 text-emerald-700 border-emerald-200"
      : status === "Escalated"
      ? "bg-amber-50 text-amber-800 border-amber-200"
      : overdue
      ? "bg-rose-50 text-rose-700 border-rose-200"
      : "bg-neutral-50 text-neutral-700 border-neutral-200";
  return (
    <span
      className={`inline-flex items-center gap-2 px-3 py-1 rounded-[14px] border ${style}`}
    >
      {status}
      {overdue && status !== "Done" ? (
        <span className="h-1.5 w-1.5 rounded-full bg-rose-500 inline-block" />
      ) : null}
    </span>
  );
}

function InlineEdit({ value, onChange, placeholder }) {
  const [editing, setEditing] = useState(false);
  const [v, setV] = useState(value || "");
  useEffect(() => setV(value || ""), [value]);
  return (
    <div>
      {!editing ? (
        <button
          className="block w-full text-left px-3 py-2 rounded-[14px] border border-neutral-200 bg-[#f9f9f8] hover:bg-white transition-all"
          onClick={() => setEditing(true)}
        >
          {v ? (
            <span className="text-neutral-800">{v}</span>
          ) : (
            <span className="text-neutral-400">{placeholder || "Edit"}</span>
          )}
        </button>
      ) : (
        <div className="flex items-center gap-2">
          <textarea
            className="w-full px-3 py-2 rounded-[14px] border border-neutral-200 bg-[#f9f9f8] focus:outline-none focus:ring-2 focus:ring-[#c7bca4]"
            rows={2}
            value={v}
            onChange={(e) => setV(e.target.value)}
          />
          <SoftButton
            onClick={() => {
              onChange(v);
              setEditing(false);
            }}
          >
            Save
          </SoftButton>
        </div>
      )}
    </div>
  );
}
